(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_read_xls_read_xls_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/read-xls/read-xls.component */ "./src/app/components/read-xls/read-xls.component.ts");
/* harmony import */ var _components_visual_data_visual_data_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/visual-data/visual-data.component */ "./src/app/components/visual-data/visual-data.component.ts");






var routes = [
    { path: "SalesChain", component: _components_login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] },
    { path: "ReadXLS", component: _components_read_xls_read_xls_component__WEBPACK_IMPORTED_MODULE_4__["ReadXlsComponent"] },
    { path: "VisualData", component: _components_visual_data_visual_data_component__WEBPACK_IMPORTED_MODULE_5__["VisualDataComponent"] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'SalesChain';
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _components_read_xls_read_xls_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/read-xls/read-xls.component */ "./src/app/components/read-xls/read-xls.component.ts");
/* harmony import */ var ngx_material_file_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-material-file-input */ "./node_modules/ngx-material-file-input/fesm5/ngx-material-file-input.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @swimlane/ngx-charts */ "./node_modules/@swimlane/ngx-charts/release/esm.js");
/* harmony import */ var _components_visual_data_visual_data_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/visual-data/visual-data.component */ "./src/app/components/visual-data/visual-data.component.ts");













var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _components_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
                _components_read_xls_read_xls_component__WEBPACK_IMPORTED_MODULE_9__["ReadXlsComponent"],
                _components_visual_data_visual_data_component__WEBPACK_IMPORTED_MODULE_12__["VisualDataComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatFormFieldModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["BrowserAnimationsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ReactiveFormsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatPaginatorModule"],
                _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_11__["NgxChartsModule"],
                ngx_material_file_input__WEBPACK_IMPORTED_MODULE_10__["MaterialFileInputModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/login/login.component.css":
/*!******************************************************!*\
  !*** ./src/app/components/login/login.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".example-button-row {\r\n    display: table-cell;\r\n  }\r\n  \r\n  .example-button-row button {\r\n    display: table-cell;\r\n    margin-right: 8px;\r\n  }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0VBQ3JCOztFQUVBO0lBQ0UsbUJBQW1CO0lBQ25CLGlCQUFpQjtFQUNuQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leGFtcGxlLWJ1dHRvbi1yb3cge1xyXG4gICAgZGlzcGxheTogdGFibGUtY2VsbDtcclxuICB9XHJcbiAgXHJcbiAgLmV4YW1wbGUtYnV0dG9uLXJvdyBidXR0b24ge1xyXG4gICAgZGlzcGxheTogdGFibGUtY2VsbDtcclxuICAgIG1hcmdpbi1yaWdodDogOHB4O1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/components/login/login.component.html":
/*!*******************************************************!*\
  !*** ./src/app/components/login/login.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"width: 100%;float: left;\">\n\n  <div style=\"width: 100%;float: left;height: 100px;\"></div>\n  <div style=\"width: 33%;float: left;\">&nbsp; </div>\n  <div style=\"width: 33%;float: left;\">\n    <form  [formGroup]=\"loginForm\" (ngSubmit)=\"onSubmit()\">\n      <mat-card style=\"width: 85%;float: left;height: 400px;padding: 0px;\">\n        <mat-card-title style=\"background:rgba(0,0,0,.06); padding:20px 20px;\">Login</mat-card-title>\n        <div>\n          <mat-form-field style=\"margin-left: 85px;width: 250px;margin-top: 30px;\">\n            <mat-label>User Name</mat-label>\n            <input matInput formControlName=\"userName\" value=\"\">\n          </mat-form-field>\n\n          <mat-form-field style=\"margin-left: 85px;width: 250px;margin-top: 30px;\">\n            <mat-label>Password</mat-label>\n            <input type=\"password\" matInput formControlName=\"password\" value=\"\">\n          </mat-form-field>\n\n          <div class=\"example-button-row\">\n            <button type=\"submit\" mat-raised-button color=\"primary\" style=\"width: 253px;margin-left: 84px;margin-top: 48px;\">Login</button>\n          </div>\n        </div>\n      </mat-card>\n    </form>\n  </div>\n  <div style=\"width: 33%;float: left;\"></div>\n    \n\n</div>"

/***/ }),

/***/ "./src/app/components/login/login.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/components/login/login.component.ts ***!
  \*****************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var LoginComponent = /** @class */ (function () {
    function LoginComponent(loginFormBuilder, router) {
        this.loginFormBuilder = loginFormBuilder;
        this.router = router;
        this.submitted = false;
    }
    LoginComponent.prototype.ngOnInit = function () {
        this.createLoginForm();
    };
    LoginComponent.prototype.createLoginForm = function () {
        this.loginForm = this.loginFormBuilder.group({
            userName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
    };
    Object.defineProperty(LoginComponent.prototype, "f", {
        get: function () { return this.loginForm.controls; },
        enumerable: true,
        configurable: true
    });
    LoginComponent.prototype.onSubmit = function () {
        this.submitted = true;
        if (this.loginForm.invalid) {
            return;
        }
        console.log("form values : " + this.f.userName.value);
        if (this.f.userName.value == 'admin' && this.f.password.value == 'admin') {
            this.router.navigateByUrl("ReadXLS").then(function (e) {
                if (e) {
                    console.log("Navigation is Successful");
                }
                else {
                    console.log("Navigation is Failed!!");
                }
            });
        }
        else {
            return;
        }
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/components/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/components/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/components/read-xls/read-xls.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/read-xls/read-xls.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".chart-legend .legend-wrap{\r\n    width: 100px;\r\n}\r\n.mat-row:hover {\r\n    background-color: #e3f8ff;\r\n  }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9yZWFkLXhscy9yZWFkLXhscy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtBQUNoQjtBQUNBO0lBQ0kseUJBQXlCO0VBQzNCIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9yZWFkLXhscy9yZWFkLXhscy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNoYXJ0LWxlZ2VuZCAubGVnZW5kLXdyYXB7XHJcbiAgICB3aWR0aDogMTAwcHg7XHJcbn1cclxuLm1hdC1yb3c6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2UzZjhmZjtcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/components/read-xls/read-xls.component.html":
/*!*************************************************************!*\
  !*** ./src/app/components/read-xls/read-xls.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<style>\n  .selectDiv{\n    background-color: #00c0ff;\n    color: white;\n  }\n  .deSelectDiv{\n    color: black;\n    background-color: whitesmoke;\n  }\n  </style>\n\n  <div style=\"width: 100%;float: left;\">\n    <div style=\"width: 50%;float: left;\">\n    <mat-form-field appearance=\"outline\">\n      <mat-label>Upload files</mat-label>\n      <ngx-mat-file-input  [accept]=\"'.xlsx'\" (change)=\"onFileChange($event)\" placeholder=\"Uplaod files\"></ngx-mat-file-input>\n      <mat-icon matSuffix>folder</mat-icon>\n    </mat-form-field>\n    </div>\n    \n  </div>\n\n    <div style=\"width: 60%;float: left;margin-left: 0px;margin-top: 5px;\">\n      \n      <mat-table [dataSource]=\"dataSource\"  class=\"mat-elevation-z8\">\n        <ng-container matColumnDef=\"{{dispCol}}\" *ngFor=\"let dispCol of displayedColumns; let colIndex = index\" >\n          <mat-header-cell *matHeaderCellDef >{{dispCol}}</mat-header-cell>\n          <mat-cell  *matCellDef=\"let element\" >\n          {{element[colIndex]}}<mat-icon style=\"color: #0080ff;font-size: 18px;\">{{dispCol == 'Actions'?'edit':''}}</mat-icon><mat-icon style=\"color: #e60000;margin-left: 10px;font-size: 18px;\">{{dispCol == 'Actions'?'delete':''}}</mat-icon>\n          </mat-cell>\n          \n        </ng-container>\n        <mat-header-row  *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\n        <mat-row  *matRowDef=\"let row; columns: displayedColumns;\" (click)=\"getRecord(row)\"></mat-row> \n      </mat-table>\n\n\n      <mat-paginator  [length]=totalRecords [pageSize]=\"7\" [pageSizeOptions]=\"[5,10,20]\" showFirstLastButtons></mat-paginator>\n    </div>\n    \n    <div style=\"width: 39%;float: left;\" *ngIf=\"tableDataVisual\">\n      <div style=\"width: 100%;float: left;text-align: center;margin-left: 10px;\">\n          <div [ngClass]=\"{'selectDiv':passDiv,'deSelectDiv':failDiv}\" style=\"width: 49%;\n          float: left;height: 62px;\n          border-radius: 2px;margin-top: 0px;\" (click)=\"showPassDiv($event)\">\n            <div style=\"margin-top: 25px;\">Students : Pased</div></div>\n          \n          <div [ngClass]=\"{'deSelectDiv':!failDiv,'selectDiv':!passDiv}\" \n          style=\"width: 49%;float: left;margin-left: 10px;border-radius: 2px;margin-top: 0px;\n          height: 62px;\" (click)=\"showFailDiv()\">\n            <div style=\"margin-top: 25px;\">Students : Failed</div></div>\n        </div>\n        <mat-card *ngIf=\"passDiv\" style=\"float: left;width: 95%;margin-left: 10px;background-color: whitesmoke;margin-top: 7px;\">\n          <div style=\"float: left;width: 100%;\">\n          <ngx-charts-pie-chart\n            [view]=\"view\"\n            [scheme]=\"colorScheme_stats\"\n            [results]=\"statsData\"\n            [legend]=\"showLegend\"\n            [explodeSlices]=\"explodeSlices\"\n            [labels]=\"showLabels\"\n            [doughnut]=\"doughnut\"\n            [gradient]=\"gradient\"\n            (select)=\"onSelect($event)\">\n            </ngx-charts-pie-chart>\n           \n          </div>\n        </mat-card>\n\n        <mat-card *ngIf=\"failDiv\" style=\"float: left;width: 95%;margin-left: 10px;background-color: whitesmoke;margin-top: 7px;\">\n          <div style=\"float: left;width: 100%;\">\n            <ngx-charts-pie-chart\n              [view]=\"view\"\n              [scheme]=\"colorScheme_stats_Fail\"\n              [results]=\"statsData_Fail\"\n              [legend]=\"showLegend\"\n              [explodeSlices]=\"explodeSlices\"\n              [labels]=\"showLabels\"\n              [doughnut]=\"doughnut\"\n              [gradient]=\"gradient\"\n              (select)=\"onSelect($event)\">\n              </ngx-charts-pie-chart>\n            </div>\n      </mat-card>\n    </div>\n   \n  <!--  <div *ngIf=\"visualButton\" style=\"width: 100%;float: left;\">\n    <div style=\"width: 50%;float: left;\">\n      <button mat-button \n      style=\"background-color: #0080ff;color: white;margin-top: 20px;width: 190px;float: left;margin-right: 10px;\" \n      (click)=\"loadChart()\">Visual Analysis</button>\n      </div>\n      </div>\n  -->\n\n   <!--   <div  *ngIf=\"visualDiv\" style=\"width: 100%;float: left;margin-top: 20px;\">\n        <div style=\"width: 100%;float: left;\">\n          <div style=\"float: left;width: 100%;text-align: center;\">\n            <div style=\"float: left;width: 50%;\"> Students :PASSED</div>\n            <div style=\"float: left;width: 50%;\">Students : FAILED</div>\n          </div>\n        \n        \n          <div #target style=\"float: left;width: 100%;margin-top: 20px;\">  \n\n            <mat-card style=\"float: left;width: 47%;margin-left: 5px;background-color: whitesmoke;\">\n            <div style=\"float: left;width: 100%;\">\n            <ngx-charts-pie-chart\n              [view]=\"view\"\n              [scheme]=\"colorScheme_stats\"\n              [results]=\"statsData\"\n              [legend]=\"showLegend\"\n              [explodeSlices]=\"explodeSlices\"\n              [labels]=\"showLabels\"\n              [doughnut]=\"doughnut\"\n              [gradient]=\"gradient\"\n              (select)=\"onSelect($event)\">\n              </ngx-charts-pie-chart>\n             \n            </div>\n          </mat-card>\n\n          <mat-card style=\"float: left;width: 47%;margin-left: 15px;background-color: whitesmoke;\">\n            <div style=\"float: left;width: 100%;\">\n              <ngx-charts-pie-chart\n                [view]=\"view\"\n                [scheme]=\"colorScheme_stats_Fail\"\n                [results]=\"statsData_Fail\"\n                [legend]=\"showLegend\"\n                [explodeSlices]=\"explodeSlices\"\n                [labels]=\"showLabels\"\n                [doughnut]=\"doughnut\"\n                [gradient]=\"gradient\"\n                (select)=\"onSelect($event)\">\n                </ngx-charts-pie-chart>\n              </div>\n        </mat-card>\n        </div>   \n        \n        \n        <div style=\"float: left;width: 100%;margin-top: 20px;\">  \n        \n          <div *ngIf=\"statsRange\" style=\"float: left;width: 50%;\">\n            <ngx-charts-pie-grid\n            [view]=\"view\"\n            [scheme]=\"colorScheme_range\"\n            [results]=\"statsData_range\"\n            (select)=\"onSelect($event)\">\n            </ngx-charts-pie-grid>\n            </div>\n        \n          </div>\n        \n        </div>\n\n\n      </div>-->\n\n\n\n\n\n"

/***/ }),

/***/ "./src/app/components/read-xls/read-xls.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/read-xls/read-xls.component.ts ***!
  \***********************************************************/
/*! exports provided: ReadXlsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadXlsComponent", function() { return ReadXlsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var src_app_services_app_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/app-services.service */ "./src/app/services/app-services.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");






var ReadXlsComponent = /** @class */ (function () {
    function ReadXlsComponent(appServices, router) {
        this.appServices = appServices;
        this.router = router;
        this.colorScheme_stats = {};
        this.colorScheme_stats_Fail = {};
        this.colorScheme_range = {};
        this.statsData = [];
        this.statsData_Fail = [];
        this.statsData_range = [];
        this.statsRange = false;
        this.view = [555, 300];
        this.showLabels = true;
        this.explodeSlices = false;
        this.doughnut = false;
        this.showLegend = true;
        this.visualDiv = false;
        this.visualButton = false;
        this.tableDataVisual = false;
        this.accpet = '';
        this.data = null;
        this.wopts = { bookType: 'xlsx', type: 'array' };
        this.totalRecords = 0;
        this.failDiv = false;
        this.passDiv = true;
        this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"]([]);
    }
    ReadXlsComponent.prototype.ngOnInit = function () {
    };
    ReadXlsComponent.prototype.onFileChange = function (evt) {
        var _this = this;
        /* wire up file reader */
        var target = (evt.target);
        if (target.files.length !== 1)
            throw new Error('Cannot use multiple files');
        var reader = new FileReader();
        reader.onload = function (e) {
            /* read workbook */
            var bstr = e.target.result;
            var wb = xlsx__WEBPACK_IMPORTED_MODULE_2__["read"](bstr, { type: 'binary' });
            /* grab first sheet */
            var wsname = wb.SheetNames[0];
            var ws = wb.Sheets[wsname];
            /* save data */
            _this.data = (xlsx__WEBPACK_IMPORTED_MODULE_2__["utils"].sheet_to_json(ws, { header: 1 }));
            //console.log(this.data[0]);
            _this.displayedColumns = _this.data[0];
            _this.displayedColumns.push("Actions");
            _this.dataSource.data = _this.data.slice(1);
            _this.totalRecords = _this.dataSource.data.length;
            console.log("data size : " + _this.totalRecords);
            _this.dataSource.paginator = _this.paginator;
            _this.loadChart();
        };
        reader.readAsBinaryString(target.files[0]);
        this.visualButton = true;
    };
    ReadXlsComponent.prototype.getRecord = function (val) {
        console.log(val);
    };
    ReadXlsComponent.prototype.loadChart = function () {
        var data = this.dataSource.data;
        // Display data
        this.displayPie(data);
        /* this.appServices.setData(this.dataSource.data)
           this.router.navigateByUrl("VisualData").then( e => {
             if(e){
               console.log("Navigation is Successful");
             }else{
               console.log("Navigation is Failed!!");
             }
           });
          */
    };
    ReadXlsComponent.prototype.displayPie = function (data) {
        console.log("data : " + data);
        var APass = 0;
        var AFail = 0;
        var BPass = 0;
        var BFail = 0;
        var CPass = 0;
        var CFail = 0;
        data.forEach(function (element) {
            console.log("section : " + element[3]);
            if (element[3] == 'A') {
                if (element[4] >= 100) {
                    APass += 1;
                }
                else {
                    AFail += 1;
                }
            }
            if (element[3] == 'B') {
                if (element[4] >= 100) {
                    BPass += 1;
                }
                else {
                    BFail += 1;
                }
            }
            if (element[3] == 'C') {
                if (element[4] >= 100) {
                    CPass += 1;
                }
                else {
                    CFail += 1;
                }
            }
        });
        console.log("A pass : " + APass);
        console.log("A fail : " + AFail);
        console.log("B pass : " + BPass);
        console.log("B fail : " + BFail);
        console.log("C pass : " + CPass);
        console.log("C fail : " + CFail);
        this.colorScheme_stats = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.colorScheme_stats_Fail = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.statsData = [
            {
                "name": "Sec A",
                "value": APass
            },
            {
                "name": "Sec B",
                "value": BPass
            },
            {
                "name": "Sec C",
                "value": CPass
            }
        ];
        this.statsData_Fail = [
            {
                "name": "Sec A",
                "value": AFail
            },
            {
                "name": "Sec B",
                "value": BFail
            },
            {
                "name": "Sec C",
                "value": CFail
            }
        ];
        this.visualDiv = true;
        this.tableDataVisual = true;
        this.passDiv = true;
        //this.failDiv=false
    };
    ReadXlsComponent.prototype.showFailDiv = function (event) {
        //event.srcElement.classList.remove("deSelectDiv")
        //event.srcElement.classList.add("selectDiv")
        this.passDiv = false;
        this.failDiv = true;
    };
    ReadXlsComponent.prototype.showPassDiv = function () {
        this.failDiv = false;
        this.passDiv = true;
    };
    ReadXlsComponent.prototype.onSelect = function (event) {
        console.log("event : " + event.name);
        var range70_80 = 0;
        var range80_90 = 0;
        var above90 = 0;
        var data = this.dataSource.data;
        data.forEach(function (element) {
            if (element[3] == 'A') {
                if (70 <= element[4] && element[4] < 80) {
                    range70_80 += 1;
                }
                if (80 <= element[4] && element[4] < 90) {
                    range80_90 += 1;
                }
                if (element[4] >= 90) {
                    above90 += 1;
                }
            }
        });
        console.log("70 - 80 : " + range70_80);
        console.log("80 - 90 : " + range80_90);
        console.log(">90 : " + above90);
        this.colorScheme_range = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.statsData_range = [
            {
                "name": "70_80",
                "value": Number(range70_80)
            },
            {
                "name": "80_90",
                "value": Number(range80_90)
            },
            {
                "name": ">90",
                "value": Number(above90)
            }
        ];
        this.statsRange = true;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"])
    ], ReadXlsComponent.prototype, "paginator", void 0);
    ReadXlsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-read-xls',
            template: __webpack_require__(/*! ./read-xls.component.html */ "./src/app/components/read-xls/read-xls.component.html"),
            styles: [__webpack_require__(/*! ./read-xls.component.css */ "./src/app/components/read-xls/read-xls.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_app_services_service__WEBPACK_IMPORTED_MODULE_4__["AppServicesService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], ReadXlsComponent);
    return ReadXlsComponent;
}());



/***/ }),

/***/ "./src/app/components/visual-data/visual-data.component.css":
/*!******************************************************************!*\
  !*** ./src/app/components/visual-data/visual-data.component.css ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvdmlzdWFsLWRhdGEvdmlzdWFsLWRhdGEuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/components/visual-data/visual-data.component.html":
/*!*******************************************************************!*\
  !*** ./src/app/components/visual-data/visual-data.component.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"width: 100%;float: left;\">\n  <div style=\"float: left;width: 100%;text-align: center;\">\n    <div style=\"float: left;width: 50%;\"> Students :PASSED</div>\n    <div style=\"float: left;width: 50%;\">Students : FAILED</div>\n  </div>\n\n  <div style=\"float: left;width: 100%;margin-top: 20px;\">  \n    <div style=\"float: left;width: 50%;\">\n    <ngx-charts-pie-chart\n      [view]=\"view\"\n      [scheme]=\"colorScheme_stats\"\n      [results]=\"statsData\"\n      [legend]=\"showLegend\"\n      [explodeSlices]=\"explodeSlices\"\n      [labels]=\"showLabels\"\n      [doughnut]=\"doughnut\"\n      (select)=\"onSelect($event)\">\n      </ngx-charts-pie-chart>\n    </div>\n\n    <div style=\"float: left;width: 50%;\">\n      <ngx-charts-pie-chart\n        [view]=\"view\"\n        [scheme]=\"colorScheme_stats_Fail\"\n        [results]=\"statsData_Fail\"\n        [legend]=\"showLegend\"\n        [explodeSlices]=\"explodeSlices\"\n        [labels]=\"showLabels\"\n        [doughnut]=\"doughnut\"\n        (select)=\"onSelect($event)\">\n        </ngx-charts-pie-chart>\n      </div>\n\n</div>   \n\n<div style=\"float: left;width: 100%;margin-top: 20px;\">  \n\n  <div *ngIf=\"statsRange\" style=\"float: left;width: 50%;\">\n    <ngx-charts-pie-grid\n    [view]=\"view\"\n    [scheme]=\"colorScheme_range\"\n    [results]=\"statsData_range\"\n    (select)=\"onSelect($event)\">\n    </ngx-charts-pie-grid>\n    </div>\n\n  </div>\n\n</div>\n\n<div style=\"float: left;width: 100%;\">\n  <button mat-button style=\"background-color: #0080ff;color: white;margin-top: 20px;\" (click)=\"toExcel()\">To Excel</button>   \n</div>\n\n"

/***/ }),

/***/ "./src/app/components/visual-data/visual-data.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/visual-data/visual-data.component.ts ***!
  \*****************************************************************/
/*! exports provided: VisualDataComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VisualDataComponent", function() { return VisualDataComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_app_services_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-services.service */ "./src/app/services/app-services.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var VisualDataComponent = /** @class */ (function () {
    function VisualDataComponent(appServices, router) {
        this.appServices = appServices;
        this.router = router;
        this.colorScheme_stats = {};
        this.colorScheme_stats_Fail = {};
        this.colorScheme_range = {};
        this.statsData = [];
        this.statsData_Fail = [];
        this.statsData_range = [];
        this.statsRange = false;
        this.view = [600, 300];
        this.showLabels = true;
        this.explodeSlices = false;
        this.doughnut = false;
        this.showLegend = true;
    }
    VisualDataComponent.prototype.ngOnInit = function () {
        this.loadChart();
    };
    VisualDataComponent.prototype.loadChart = function () {
        var data = this.appServices.getData();
        this.classData = data;
        console.log("data : " + data);
        var APass = 0;
        var AFail = 0;
        var BPass = 0;
        var BFail = 0;
        var CPass = 0;
        var CFail = 0;
        data.forEach(function (element) {
            console.log("section : " + element[3]);
            if (element[3] == 'A') {
                if (element[4] >= 100) {
                    APass += 1;
                }
                else {
                    AFail += 1;
                }
            }
            if (element[3] == 'B') {
                if (element[4] >= 100) {
                    BPass += 1;
                }
                else {
                    BFail += 1;
                }
            }
            if (element[3] == 'C') {
                if (element[4] >= 100) {
                    CPass += 1;
                }
                else {
                    CFail += 1;
                }
            }
        });
        console.log("A pass : " + APass);
        console.log("A fail : " + AFail);
        console.log("B pass : " + BPass);
        console.log("B fail : " + BFail);
        console.log("C pass : " + CPass);
        console.log("C fail : " + CFail);
        this.colorScheme_stats = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.colorScheme_stats_Fail = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.statsData = [
            {
                "name": "Section A",
                "value": APass
            },
            {
                "name": "Section B",
                "value": BPass
            },
            {
                "name": "Section c",
                "value": CPass
            }
        ];
        this.statsData_Fail = [
            {
                "name": "Section A",
                "value": AFail
            },
            {
                "name": "Section B",
                "value": BFail
            },
            {
                "name": "Section C",
                "value": CFail
            }
        ];
    };
    VisualDataComponent.prototype.onSelect = function (event) {
        console.log("event : " + event.name);
        var range70_80 = 0;
        var range80_90 = 0;
        var above90 = 0;
        var data = this.classData;
        data.forEach(function (element) {
            if (element[3] == 'A') {
                if (70 <= element[4] && element[4] < 80) {
                    range70_80 += 1;
                }
                if (80 <= element[4] && element[4] < 90) {
                    range80_90 += 1;
                }
                if (element[4] >= 90) {
                    above90 += 1;
                }
            }
        });
        console.log("70 - 80 : " + range70_80);
        console.log("80 - 90 : " + range80_90);
        console.log(">90 : " + above90);
        this.colorScheme_range = {
            domain: ['#95b4f5', '#ffc862', '#ff8989']
        };
        this.statsData_range = [
            {
                "name": "70_80",
                "value": Number(range70_80)
            },
            {
                "name": "80_90",
                "value": Number(range80_90)
            },
            {
                "name": ">90",
                "value": Number(above90)
            }
        ];
        this.statsRange = true;
    };
    VisualDataComponent.prototype.toExcel = function () {
        this.router.navigateByUrl("ReadXLS").then(function (e) {
            if (e) {
                console.log("Navigation is Successful");
            }
            else {
                console.log("Navigation is Failed!!");
            }
        });
    };
    VisualDataComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-visual-data',
            template: __webpack_require__(/*! ./visual-data.component.html */ "./src/app/components/visual-data/visual-data.component.html"),
            styles: [__webpack_require__(/*! ./visual-data.component.css */ "./src/app/components/visual-data/visual-data.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_app_services_service__WEBPACK_IMPORTED_MODULE_2__["AppServicesService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], VisualDataComponent);
    return VisualDataComponent;
}());



/***/ }),

/***/ "./src/app/services/app-services.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/app-services.service.ts ***!
  \**************************************************/
/*! exports provided: AppServicesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppServicesService", function() { return AppServicesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppServicesService = /** @class */ (function () {
    function AppServicesService() {
    }
    AppServicesService.prototype.setData = function (data) {
        this.data = data;
    };
    AppServicesService.prototype.getData = function () {
        return this.data;
    };
    AppServicesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AppServicesService);
    return AppServicesService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\esilvil\Desktop\Vishal_May 2019\Vishal\Project\SalesChain\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map